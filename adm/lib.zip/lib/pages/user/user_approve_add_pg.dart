import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'user_approve_add_room.dart'; // 👈 make sure this path is correct

class ApprovePgPage extends StatelessWidget {
  const ApprovePgPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: Text(
          'Approve PG',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Owner Details Card
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              color: Colors.grey.shade100,
              child: Padding(
                padding: EdgeInsets.all(3.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.group,
                          size: 22.sp,
                          color: Colors.teal.shade800,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          "Owner Details",
                          style: TextStyle(
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.teal.shade700,
                          ),
                        ),
                      ],
                    ),
                    Divider(
                      height: 3.h,
                      thickness: 1,
                      color: Colors.grey.shade300,
                    ),
                    SizedBox(height: 1.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Owner Name",
                        prefixIcon: const Icon(Icons.person),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Phone No",
                        prefixIcon: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(width: 2.w),
                            Text(
                              "+91 ",
                              style: TextStyle(
                                fontSize: 11.sp,
                                color: Colors.black87,
                              ),
                            ),
                            const VerticalDivider(width: 8),
                          ],
                        ),
                        prefixIconConstraints: const BoxConstraints(
                          minWidth: 0,
                          minHeight: 0,
                        ),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      keyboardType: TextInputType.number,
                      maxLength: 10,
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Email",
                        prefixIcon: const Icon(Icons.email),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      keyboardType: TextInputType.emailAddress,
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 2.h),

            // PG Details Card
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              color: Colors.grey.shade100,
              child: Padding(
                padding: EdgeInsets.all(3.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.home_work_rounded,
                          size: 22.sp,
                          color: Colors.teal.shade800,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          "PG Details",
                          style: TextStyle(
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.teal.shade700,
                          ),
                        ),
                      ],
                    ),
                    Divider(
                      height: 3.h,
                      thickness: 1,
                      color: Colors.grey.shade300,
                    ),
                    SizedBox(height: 1.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "PG Name",
                        prefixIcon: const Icon(Icons.home_rounded),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Street",
                        prefixIcon: const Icon(Icons.alt_route_rounded),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Area",
                        prefixIcon: const Icon(Icons.map_rounded),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Pincode",
                        prefixIcon: const Icon(Icons.local_post_office_rounded),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "City",
                        prefixIcon: const Icon(Icons.location_city_rounded),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 1.5.h),

                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "State",
                        prefixIcon: const Icon(Icons.location_on_rounded),
                        suffixIcon: const Icon(Icons.edit, size: 18),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    SizedBox(height: 1.5.h),

                    // Image Upload UI + edit icon
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(
                        vertical: 2.h,
                        horizontal: 3.w,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade400),
                        color: Colors.white,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.image_outlined,
                                size: 20.sp,
                                color: Colors.grey.shade700,
                              ),
                              SizedBox(width: 3.w),
                              Text(
                                'PG Images',
                                style: TextStyle(
                                  fontSize: 11.sp,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                            ],
                          ),
                          const Icon(Icons.edit, size: 18),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 3.h),

            // Buttons Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: SizedBox(
                    height: 6.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueGrey,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        'Cancel',
                        style: TextStyle(fontSize: 12.sp, color: Colors.white),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: SizedBox(
                    height: 6.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const ApproveRoomsPage(),
                          ),
                        );
                      },
                      child: Text(
                        'Next',
                        style: TextStyle(fontSize: 12.sp, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}
