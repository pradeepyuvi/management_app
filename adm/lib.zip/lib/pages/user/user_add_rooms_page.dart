import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class AddRoomsPage extends StatefulWidget {
  const AddRoomsPage({super.key});

  @override
  State<AddRoomsPage> createState() => _AddRoomsPageState();
}

class _AddRoomsPageState extends State<AddRoomsPage> {
  final List<Map<String, dynamic>> roomFields = [
    {'controller': TextEditingController(), 'sharing': '1'},
  ];

  void addRoomField() {
    setState(() {
      roomFields.add({'controller': TextEditingController(), 'sharing': '1'});
    });
  }

  @override
  void dispose() {
    for (final room in roomFields) {
      (room['controller'] as TextEditingController).dispose();
    }
    super.dispose();
  }

  void submitUiOnly() {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('UI only: Submit All tapped')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: Text(
          'Add Rooms',
          style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              color: Colors.grey.shade100,
              child: Padding(
                padding: EdgeInsets.all(3.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header row like Add PG
                    Row(
                      children: [
                        Icon(
                          Icons.meeting_room_rounded,
                          size: 22.sp,
                          color: Colors.teal.shade800,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          "Room Details",
                          style: TextStyle(
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.teal.shade700,
                          ),
                        ),
                      ],
                    ),
                    Divider(
                      height: 3.h,
                      thickness: 1,
                      color: Colors.grey.shade300,
                    ),
                    SizedBox(height: 1.h),

                    // Dynamic room rows
                    ...roomFields.asMap().entries.map((entry) {
                      int index = entry.key;
                      var room = entry.value;

                      return Padding(
                        padding: EdgeInsets.symmetric(vertical: 1.h),
                        child: Row(
                          children: [
                            // Room No
                            Expanded(
                              flex: 2,
                              child: TextFormField(
                                controller: room['controller'],
                                decoration: InputDecoration(
                                  labelText: 'Room No',
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  filled: true,
                                  fillColor: Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(width: 3.w),

                            // Sharing dropdown
                            Expanded(
                              flex: 2,
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: 3.w),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: Colors.grey.shade400,
                                  ),
                                  color: Colors.white,
                                ),
                                child: DropdownButton<String>(
                                  value: room['sharing'],
                                  isExpanded: true,
                                  underline: const SizedBox(),
                                  items: ['1', '2', '3', '4']
                                      .map(
                                        (e) => DropdownMenuItem(
                                          value: e,
                                          child: Text('$e Sharing'),
                                        ),
                                      )
                                      .toList(),
                                  onChanged: (val) {
                                    setState(() {
                                      roomFields[index]['sharing'] = val!;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),

                    SizedBox(height: 2.h),

                    Align(
                      alignment: Alignment.centerRight,
                      child: ElevatedButton.icon(
                        onPressed: addRoomField,
                        icon: const Icon(Icons.add),
                        label: Text(
                          'Add Room',
                          style: TextStyle(fontSize: 11.sp),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueGrey,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 3.h),

            // Submit button like in Add PG
            Center(
              child: SizedBox(
                width: 60.w,
                height: 6.h,
                child: ElevatedButton(
                  onPressed: submitUiOnly,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'Submit All',
                    style: TextStyle(fontSize: 12.sp, color: Colors.white),
                  ),
                ),
              ),
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}
