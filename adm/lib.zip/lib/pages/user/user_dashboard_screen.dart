import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import '../user/user_pg_list.dart';

class UserDashboardScreen extends StatelessWidget {
  const UserDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: Text(
          'User Dashboard',
          style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(5.w),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSectionCard(
                title: 'Add PG',
                icon: Icons.add_business,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const UserPgListScreen(mode: PgListMode.add),
                    ),
                  );
                },
              ),
              SizedBox(height: 3.h),
              _buildSectionCard(
                title: 'Approve PG',
                icon: Icons.verified,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const UserPgListScreen(mode: PgListMode.approve),
                    ),
                  );
                },
              ),
              SizedBox(height: 3.h),
              _buildSectionCard(
                title: 'PG Count',
                icon: Icons.format_list_numbered,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const UserPgListScreen(), // count mode
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12.sp),
      child: Container(
        width: 80.w,
        padding: EdgeInsets.symmetric(vertical: 3.h, horizontal: 4.w),
        decoration: BoxDecoration(
          color: Colors.blue.shade50,
          borderRadius: BorderRadius.circular(12.sp),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              blurRadius: 6,
              offset: const Offset(2, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, size: 22.sp, color: Colors.blue.shade800),
            SizedBox(width: 4.w),
            Text(
              title,
              style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
